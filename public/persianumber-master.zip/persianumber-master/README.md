How to use
----------
----------

1. First download persianumber.min.js file.
2. Add This file to head section of document after jQuery library.
3. In .ready() event for document use this syntax: $('.persianumber').persiaNumber();
4. For each element that you want convert numbers to persian use "persianumber" html class.
